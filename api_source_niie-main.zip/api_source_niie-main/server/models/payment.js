//model
const mongoose = require ('mongoose');

mongoose.Promise = global.Promise;

const paymentSchema = new mongoose.Schema(
	{
		CodeProfessor:{
			type: String,
			required: true,
			trim:true
		},
		NameProfessor:{
			type: String
			
		},
        AddressProfessor:{
            type: String
        },
        
        Level:{
            type: String
        },
	},
	
);

const Payment = mongoose.model('Payment', paymentSchema)

module.exports = Payment