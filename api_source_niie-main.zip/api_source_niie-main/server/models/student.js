//model
const mongoose = require ('mongoose');

mongoose.Promise = global.Promise;

const studentSchema = new mongoose.Schema(
	{
		Name: {
			type: String,
			required: true,
			trim: true
		},
		Dayofbirth: {
			type: String
		},
        Address:{
            type: String
        },
        ID:{
            type: Number
        },
        Course:{
            type: String
        }
	},
	
);

const Student = mongoose.model('Student', studentSchema)

module.exports = Student