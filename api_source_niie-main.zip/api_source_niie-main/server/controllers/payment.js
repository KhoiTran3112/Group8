
const Payment = require('../models/payment');


exports.newPayment= function newPayment(req, res) {
	const payment = new Payment({
	  CodeProfessor:req.body.CodeProfessor,
	  NameProfessor:req.body.NameProfessor,
      AddressProfessor:req.body.AddressProfessor,
      Level:req.body.Level,
	});
	
	return payment
	  .save()
	  .then((newPayment) => {
		return res.status(201).json({
		  success: true,
		  message: 'New payment created successfully',
		  payment: newPayment,
		});
	  })
	  .catch((error) => {
		  console.log(error);
		res.status(500).json({
		  success: false,
		  message: 'Server error. Please try again.',
		  error: error.message,
		});
	  });
  }
  exports.Payment_getAll = function Payment_getAll(req,res){
	Payment.find({})
    .then((docs) => {
      return res.status(200).json({
        success: true,
        message: "A list of all payment",
        Payment: docs,
      });
    })
    .catch((err) => {
      return res.status(500).json({
        success: fasle,
        message: "Server error. Please try again",
        error: err.message,
      });
    });
  }
  // get single course
exports.Payment_getSingle =function Payment_getSingle(req, res) {
	const id = req.params.paymentId;
	Payment.findById(id)
	  .then((getSingle) => {
		res.status(200).json({
		  success: true,
		  message: `More on ${getSingle.Name}`,
		  Payment: getSingle,
		});
	  })
	  .catch((err) => {
		res.status(500).json({
		  success: false,
		  message: 'This course does not exist',
		  error: err.message,
		});
	 });
  }
  // update course
exports.Payment_update= function Payment_update(req, res) {
	const id = req.params.courseId;
	const updateObject = req.body;
	Payment.update({ _id:id }, { $set:updateObject })
	  .exec()
	  .then(() => {
		res.status(200).json({
		  success: true,
		  message: 'Course is updated',
		  updatePayment: updateObject,
		});
	  })
	  .catch((err) => {
		res.status(500).json({
		  success: false,
		  message: 'Server error. Please try again.'
		});
	  });
  }
  // delete a course
exports.Payment_delete= function Payment_delete(req, res) {
	const id = req.params.courseId;
	Payment.findByIdAndRemove(id)
	  .exec()
	  .then(()=> res.status(204).json({
		success: true,
	  }))
	  .catch((err) => res.status(500).json({
		success: false,
	  }));
  }