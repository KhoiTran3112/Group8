const Course = require ('../models/course');
const Student = require('../models/student');


exports.newStudent = function newStudent(req, res) {
	const student = new Student({
	  Name: req.body.Name,
	  Dayofbirth: req.body.Dayofbirth,
      Address: req.body.Address,
      ID:req.body.ID,
      Course:req.body.Course,
	});
	
	return student
	  .save()
	  .then((newStudent) => {
		return res.status(201).json({
		  success: true,
		  message: 'New student created successfully',
		  Student: newStudent,
		});
	  })
	  .catch((error) => {
		  console.log(error);
		res.status(500).json({
		  success: false,
		  message: 'Server error. Please try again.',
		  error: error.message,
		});
	  });
  }