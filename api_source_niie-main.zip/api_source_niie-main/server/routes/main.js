//router
const express = require('express');
const createCourse = require ('../controllers/course');
const Student= require('../controllers/student');
const Payment= require('../controllers/payment');
const router = express.Router();

//create a new course
router.post('/courses', createCourse.course_create);
router.get('/courses',createCourse.course_getAll);
router.get('/courses/:courseId', createCourse.course_getSingleCourse);
router.patch('/courses/:courseId', createCourse.course_UpdateCourse);
router.delete('/courses/:courseId', createCourse.course_DeleteCourse);


router.post('/Student',Student.newStudent);

router.post('/payment', Payment.newPayment);
router.get('/payment',Payment.Payment_getAll);
router.get('/payment/:paymentId', Payment.Payment_getSingle);
router.patch('/payment/:paymentId', Payment.Payment_update);
router.delete('/payment/:paymentId', Payment.Payment_delete);

module.exports = router

